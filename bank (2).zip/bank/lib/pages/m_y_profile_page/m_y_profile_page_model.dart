import '/flutter_flow/flutter_flow_util.dart';
import 'm_y_profile_page_widget.dart' show MYProfilePageWidget;
import 'package:flutter/material.dart';

class MYProfilePageModel extends FlutterFlowModel<MYProfilePageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
