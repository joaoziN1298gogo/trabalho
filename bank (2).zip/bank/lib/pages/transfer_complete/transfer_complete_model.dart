import '/flutter_flow/flutter_flow_util.dart';
import 'transfer_complete_widget.dart' show TransferCompleteWidget;
import 'package:flutter/material.dart';

class TransferCompleteModel extends FlutterFlowModel<TransferCompleteWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
