import '/flutter_flow/flutter_flow_util.dart';
import 'home_page_alt1_widget.dart' show HomePageAlt1Widget;
import 'package:flutter/material.dart';

class HomePageAlt1Model extends FlutterFlowModel<HomePageAlt1Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
