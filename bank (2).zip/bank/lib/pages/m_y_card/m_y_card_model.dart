import '/flutter_flow/flutter_flow_util.dart';
import 'm_y_card_widget.dart' show MYCardWidget;
import 'package:flutter/material.dart';

class MYCardModel extends FlutterFlowModel<MYCardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
