import '/flutter_flow/flutter_flow_util.dart';
import 'budget_d_e_l_e_t_e_widget.dart' show BudgetDELETEWidget;
import 'package:flutter/material.dart';

class BudgetDELETEModel extends FlutterFlowModel<BudgetDELETEWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
