import '/flutter_flow/flutter_flow_util.dart';
import 'm_y_budgets_widget.dart' show MYBudgetsWidget;
import 'package:flutter/material.dart';

class MYBudgetsModel extends FlutterFlowModel<MYBudgetsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
