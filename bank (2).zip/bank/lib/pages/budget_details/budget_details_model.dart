import '/flutter_flow/flutter_flow_util.dart';
import 'budget_details_widget.dart' show BudgetDetailsWidget;
import 'package:flutter/material.dart';

class BudgetDetailsModel extends FlutterFlowModel<BudgetDetailsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
