import '/flutter_flow/flutter_flow_util.dart';
import 'home_page_alt_widget.dart' show HomePageAltWidget;
import 'package:flutter/material.dart';

class HomePageAltModel extends FlutterFlowModel<HomePageAltWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
