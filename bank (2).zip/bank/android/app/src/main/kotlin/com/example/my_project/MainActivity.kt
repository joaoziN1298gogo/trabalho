package com.flutterflow.finwallet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
